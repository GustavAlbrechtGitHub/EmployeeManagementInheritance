package StaffManagementProjectPackage;

import java.util.Scanner;

public class TryCatch {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        //try catch i read int metod

        String tal1 = "56.2";

        String tal2 = "50.5";

        System.out.println(Double.parseDouble(tal1) + Double.parseDouble(tal2));

    }
}
